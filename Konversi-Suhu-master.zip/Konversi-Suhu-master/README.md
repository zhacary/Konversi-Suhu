# Konversi-Suhu
Aplikasi Konversi Suhu

# Tutorial Build with Android Studio
https://rivaldi48.blogspot.com/2020/04/Tutorial-Membuat-Aplikasi-Konversi-Suhu-dengan-Android-Studio.html

# Tutorial Build with Video
https://youtu.be/41iNVTwwZMg
